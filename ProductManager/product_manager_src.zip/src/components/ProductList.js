import React, { useEffect, useState } from 'react'
import { Link, Router } from '@reach/router'


const ProductList = ({productList}) => {
    console.log(productList)
    return(
            <div>
                {productList.map((product, idx) => {
                    return <p key={idx}>
                        <Link to={`/products/${product._id}`}>{product.title}</Link>
                        </p>

                })}
            </div>
            
    )
}

export default ProductList