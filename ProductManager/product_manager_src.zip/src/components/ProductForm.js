import React, { useState } from 'react'
import axios from 'axios'


const ProductForm = ({product, setProduct, submitState,setSubmitState}) => {
    
    
    const changeHandler = (e) => {
        setProduct({
            ...product,
            [e.target.name] : e.target.value
        })
    }

    const onSubmitHandler = (e) => {
        e.preventDefault()
        axios.post('http://localhost:8000/api/products/new', product) 
            .then(res=> {
                setSubmitState(!submitState)
            })
            .catch(err=> console.log("Error: ", err))
    }

    return (
        <form onSubmit={onSubmitHandler}>
            <p>
                <label>Product Title: </label>
                <input type="text" name="title"  onChange={changeHandler}/>
            </p>
            <p>
                <label>Price: </label>
                <input type="text" name="price" onChange={changeHandler} />
            </p>
            <p>
                <label>Description: </label>
                <input type="text" name="description"  onChange={changeHandler}/>
            </p>
            <input type="submit" />
        </form>
    )
}

export default ProductForm