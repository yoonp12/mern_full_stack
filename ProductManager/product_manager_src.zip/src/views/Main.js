import React, { useEffect, useState } from 'react'
import ProductForm from '../components/ProductForm'
import ProductList from '../components/ProductList'
import Detail from './Detail'
import { Router } from '@reach/router'
import axios from 'axios'

const Main = () => {
    const [productList, setProductList] = useState([])
    // const [loaded, setLoaded] = useState(false)
    const [submitState, setSubmitState] = useState(false)

    const [product, setProduct] = useState({
        title: "",
        price: "",
        description: ""
    })
    useEffect(() => {
        axios.get('http://localhost:8000/api/products')
            .then(res => 
                setProductList(res.data.products)
                // setLoaded(true)
            );
    }, [submitState])
    
    return(
        <div>
            <ProductForm product={product} setProduct={setProduct} submitState={submitState} setSubmitState={setSubmitState} />
            
            <Router>
                <ProductList path="/" productList={productList}/>
                <Detail path="products/:id" />
            </Router>
        </div>
    )
}

export default Main