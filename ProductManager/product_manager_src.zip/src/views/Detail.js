import React, { useEffect, useState } from 'react'
import Axios from 'axios'


const Detail = (props) => {
    const [detail, setDetail] = useState ({})
    
    useEffect(() => {
        Axios.get("http://localhost:8000/api/products/"+props.id)
        .then(res => {
            // detail.push(res.data.product)
            setDetail(res.data.product)
        });
    }, [])
    console.log("Detail component")
    return(
        <table className="table table-striped">
            <thead>
                <tr>
                <th></th>
                <td>Product Information</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                <th scope="row">Title:</th>
                <td>{detail.title}</td>
                </tr>
                <tr>
                <th scope="row">Price:</th>
                <td>{detail.price}</td>
                </tr>
                <tr>
                <th scope="row">Description:</th>
                <td>{detail.description}</td>
                </tr>
            </tbody>
        </table>
    )
}
export default Detail